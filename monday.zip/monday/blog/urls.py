from unicodedata import name
from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('<slug>', views.article_detail, name='article_detail'),
    path('article_create/', views.article_create, name='article_create'),
    path('<slug>/edit', views.edit_article, name="article_edit"),
    path('<slug>/delete', views.delete_article, name="article_delete")
]
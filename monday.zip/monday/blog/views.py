from django.shortcuts import render, redirect
from .models import Article
from .forms import ArticleForm
from django.contrib.auth.decorators import login_required

@login_required(login_url='/users/sign_in')
def home(request):
    articles = Article.objects.all()
    return render(request, 'home.html', {'articles': articles})


def article_detail(request, slug):
    article = Article.objects.get(slug=slug)
    return render(request, 'article_detail.html', {'article': article})

def article_create(request):
    form = ArticleForm(request.POST, request.FILES)
    if request.method == 'POST' and form.is_valid():
        form.save()
        return redirect('blog:home')
    form = ArticleForm()     
    return render(request, 'article_create.html', {'form': form})

def edit_article(request, slug):
    article = Article.objects.get(slug=slug)
    form = ArticleForm(request.POST or None, request.FILES or None, instance=article)
    if form.is_valid():
        form.save()
        print(slug)
        return redirect('blog:article_detail', slug=request.POST.get('slug'))
    return render(request, 'edit_article.html', {'form': form, 'article': article})    


def delete_article(request, slug):
    article = Article.objects.get(slug=slug)
    if request.method == 'POST':
        article.delete()
        return redirect('blog:home')
    return render(request, 'delete_article.html', {'article': article})        